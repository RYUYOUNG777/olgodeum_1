import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart'; // Cupertino와 함께 Material도 사용 가능
import 'package:firebase_core/firebase_core.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:google_sign_in/google_sign_in.dart';

void main() async {
  WidgetsFlutterBinding.ensureInitialized();
  await Firebase.initializeApp(); // Firebase 초기화
  runApp(const MyApp());
}

class MyApp extends StatelessWidget {
  const MyApp({super.key});

  @override
  Widget build(BuildContext context) {
    return CupertinoApp(
      debugShowCheckedModeBanner: false,
      title: 'Motion Recognition App',
      theme: const CupertinoThemeData(
        primaryColor: CupertinoColors.activeBlue,
      ),
      home: const LoginPage(),
    );
  }
}

class LoginPage extends StatefulWidget {
  const LoginPage({Key? key}) : super(key: key);

  @override
  LoginPageState createState() => LoginPageState();
}

class LoginPageState extends State<LoginPage> {
  final FirebaseAuth _auth = FirebaseAuth.instance;
  final GoogleSignIn _googleSignIn = GoogleSignIn();

  /// 구글 계정으로 로그인
  Future<void> _signInWithGoogle(BuildContext context) async {
    try {
      final GoogleSignInAccount? googleUser = await _googleSignIn.signIn();
      if (googleUser == null) {
        // 사용자가 로그인 취소
        return;
      }
      final GoogleSignInAuthentication googleAuth =
      await googleUser.authentication;

      final AuthCredential credential = GoogleAuthProvider.credential(
        accessToken: googleAuth.accessToken,
        idToken: googleAuth.idToken,
      );

      // 파이어베이스 인증
      await _auth.signInWithCredential(credential);

      // 로그인 성공 후 사용자 정보 입력 페이지로 이동
      if (mounted) {
        Navigator.push(
          context,
          CupertinoPageRoute(
            builder: (context) => const UserDetailsPage(),
          ),
        );
      }
    } catch (e) {
      debugPrint("Error signing in with Google: $e");
      if (mounted) {
        // 에러 메시지 표시
        showCupertinoDialog(
          context: context,
          builder: (_) => CupertinoAlertDialog(
            title: const Text('로그인 에러'),
            content: Text('Google Sign-In 실패: $e'),
            actions: [
              CupertinoDialogAction(
                isDefaultAction: true,
                child: const Text('확인'),
                onPressed: () => Navigator.of(context).pop(),
              ),
            ],
          ),
        );
      }
    }
  }

  /// 구글 로그아웃(테스트 용도)
  Future<void> _signOut() async {
    await _googleSignIn.signOut();
    await _auth.signOut();
    debugPrint("User Signed Out");
  }

  @override
  Widget build(BuildContext context) {
    return CupertinoPageScaffold(
      navigationBar: const CupertinoNavigationBar(
        middle: Text('헬스 앱 - 로그인'),
      ),
      child: SafeArea(
        child: Center(
          child: Column(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              CupertinoButton.filled(
                onPressed: () => _signInWithGoogle(context),
                child: const Text('구글 계정으로 로그인'),
              ),
              const SizedBox(height: 20),
              CupertinoButton(
                color: CupertinoColors.activeBlue,
                onPressed: () => _signInWithGoogle(context),
                child: const Text('파란색 버튼으로 로그인'),
              ),
              const SizedBox(height: 20),
              // 디버그/테스트를 위해 로그아웃 버튼(실서비스 시 제거 가능)
              CupertinoButton(
                onPressed: _signOut,
                child: const Text('로그아웃(테스트)'),
              ),
            ],
          ),
        ),
      ),
    );
  }
}

class UserDetailsPage extends StatefulWidget {
  const UserDetailsPage({Key? key}) : super(key: key);

  @override
  UserDetailsPageState createState() => UserDetailsPageState();
}

class UserDetailsPageState extends State<UserDetailsPage> {
  final GlobalKey<FormState> _formKey = GlobalKey<FormState>();

  // 사용자가 입력할 기본 정보들
  String _name = '';
  String _age = '';
  String _height = '';
  String _weight = '';

  @override
  Widget build(BuildContext context) {
    return CupertinoPageScaffold(
      navigationBar: const CupertinoNavigationBar(
        middle: Text('신체 정보 입력'),
      ),
      child: SafeArea(
        child: Form(
          key: _formKey,
          child: CupertinoScrollbar(
            child: ListView(
              padding: const EdgeInsets.all(20),
              children: [
                const SizedBox(height: 20),
                _buildTextField(
                  label: '이름',
                  placeholder: '이름을 입력하세요',
                  onSaved: (val) => _name = val ?? '',
                  validator: (val) {
                    if (val == null || val.isEmpty) {
                      return '이름은 필수 입력입니다.';
                    }
                    return null;
                  },
                ),
                const SizedBox(height: 20),
                _buildTextField(
                  label: '나이',
                  placeholder: '나이를 입력하세요',
                  keyboardType: TextInputType.number,
                  onSaved: (val) => _age = val ?? '',
                  validator: (val) {
                    if (val == null || val.isEmpty) {
                      return '나이는 필수 입력입니다.';
                    }
                    return null;
                  },
                ),
                const SizedBox(height: 20),
                _buildTextField(
                  label: '키(cm)',
                  placeholder: '키를 입력하세요',
                  keyboardType: TextInputType.number,
                  onSaved: (val) => _height = val ?? '',
                  validator: (val) {
                    if (val == null || val.isEmpty) {
                      return '키는 필수 입력입니다.';
                    }
                    return null;
                  },
                ),
                const SizedBox(height: 20),
                _buildTextField(
                  label: '몸무게(kg)',
                  placeholder: '몸무게를 입력하세요',
                  keyboardType: TextInputType.number,
                  onSaved: (val) => _weight = val ?? '',
                  validator: (val) {
                    if (val == null || val.isEmpty) {
                      return '몸무게는 필수 입력입니다.';
                    }
                    return null;
                  },
                ),
                const SizedBox(height: 40),
                CupertinoButton.filled(
                  child: const Text('제출'),
                  onPressed: _submitForm,
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }

  Widget _buildTextField({
    required String label,
    required String placeholder,
    TextInputType keyboardType = TextInputType.text,
    required FormFieldSetter<String> onSaved,
    required FormFieldValidator<String> validator,
  }) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Text(label, style: const TextStyle(fontSize: 16)),
        const SizedBox(height: 8),
        CupertinoTextFormFieldRow(
          placeholder: placeholder,
          keyboardType: keyboardType,
          onSaved: onSaved,
          validator: validator,
          padding: const EdgeInsets.symmetric(horizontal: 0, vertical: 12),
        ),
      ],
    );
  }

  void _submitForm() {
    if (_formKey.currentState?.validate() ?? false) {
      _formKey.currentState?.save();
      // 추후 여기에 Firebase 저장 로직 등을 추가하면 됨
      debugPrint('이름: $_name, 나이: $_age, 키: $_height, 몸무게: $_weight');

      // 입력 완료 후 다음 페이지 또는 홈 화면으로 이동
      Navigator.push(
        context,
        CupertinoPageRoute(
          builder: (context) => CupertinoPageScaffold(
            navigationBar: const CupertinoNavigationBar(
              middle: Text('정보 입력 완료'),
            ),
            child: Center(
              child: Text(
                '$_name님, 정보가 정상적으로 입력되었습니다!\n'
                    '나이: $_age, 키: $_height, 몸무게: $_weight',
                textAlign: TextAlign.center,
                style: const TextStyle(fontSize: 18),
              ),
            ),
          ),
        ),
      );
    }
  }
}
